# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import urllib.request
from time import sleep
import datetime

useragent = "SolborgRecruiter v0.1.0 solborgdev@gmail.com"
separator = "========================================"
numsent = 0

def find_between(s, first, last):
    try:
        start = s.index(first) + len(first)
        end = s.index(last, start)
        return s[start:end]
    except ValueError:
        return ""

def latest_nation():
    req = urllib.request.Request(
        "https://www.nationstates.net/cgi-bin/api.cgi?q=newnations",
        data = None,
        headers = {"User-Agent": useragent}
    )
    raw_xml = urllib.request.urlopen(req).read().decode("utf-8")
    return find_between(raw_xml, "<NEWNATIONS>", ",")

def print_stamped(to_print):
    timestamp = str(datetime.datetime.now()).split(".")[0]
    print("[{0}] {1}".format(timestamp, to_print))


print("Python Command Line Recruiter by Solborg, v0.1.0")

# Getting inputs from user

while True:
    print(separator)
    clientkey = input("Please enter your client key: ")
    secretkey = input("Please enter your secret key: ")
    tgid = input("Please enter your telegram ID: ")

    while True:
        print(separator)
        print("Will send telegrams to new nations every 180 seconds with:")
        print("Client key ......", clientkey)
        print("Secret key ......", secretkey)
        print("Telegram ID .....", tgid)
        confirmation = input("Is this information correct? [y/n] ").lower()

        if confirmation in ("y", "n"):
            break
        else:
            print("Did not recognize '" + confirmation + "'")

    if confirmation == "y":
        break
    else:
        print("Please enter the parameters again.")

print(separator)
print("Sending telegrams...")

# Sending telegrams

nation_old = ""

while True:
    nation = latest_nation()
    print_stamped("Got nation " + nation)

    if nation == nation_old:
        print_stamped("Got the same nation. Trying again in 180 seconds.")
    else:
        tg_request = urllib.request.Request(
            "https://www.nationstates.net/cgi-bin/api.cgi?a=sendTG&client={0}&tgid={1}&key={2}&to={3}".format(clientkey, tgid, secretkey, nation),
            data = None,
            headers = {"User-Agent": useragent}
        )
        tg_feedback = urllib.request.urlopen(tg_request).read().decode("utf-8")
        print_stamped("Received status: " + tg_feedback)

        nation_old = nation

    sleep(183)
